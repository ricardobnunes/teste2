Odoo Projects
=============

[![Fuck It Ship It](https://forthebadge.com/images/badges/fuck-it-ship-it.svg)](https://forthebadge.com)
[![Built With Resentment](https://forthebadge.com/images/badges/built-with-resentment.svg)](https://forthebadge.com)

A monorepo of my proprietary Odoo addons for JNA Entertainment Specialists.
