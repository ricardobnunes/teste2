from odoo import models, fields

class SalesOrderSpectrumVoiceLine(models.Model):
    _name = 'jna.sales.order.spectrum.voiceline'
    _description = 'JNA Spectrum Sales Order Voice Line'
    _order = 'order_id, id'

    order_id = fields.Many2one(string='Order', comodel_name='jna.sales.order.spectrum', required=True, index=True, readonly=True, ondelete='cascade')
    number = fields.Char(string='Number', required=True)
    type = fields.Selection(string='Type', selection=[
        ('new', 'New Line'),
        ('transferred', 'Transferred Line'),
    ], required=True, index=True)
