from odoo import models, fields, api

class SalesOrderSpectrum(models.Model):
    _name = 'jna.sales.order.spectrum'
    _description = 'JNA Spectrum Sales Order'
    _inherit = ['jna.sales.ordermixin']

    @api.model
    def _filter_internet_products(self):
        return [('categ_id', 'child_of', self.env.ref('jna_sales_spectrum.product_category_internet').id)]

    @api.model
    def _filter_cable_products(self):
        return [('categ_id', 'child_of', self.env.ref('jna_sales_spectrum.product_category_cable').id)]

    @api.model
    def _filter_voiceline_products(self):
        return [('categ_id', 'child_of', self.env.ref('jna_sales_spectrum.product_category_voiceline').id)]

    type_play = fields.Selection(string='Play Type', selection=[
        ('single', 'Single Play'),
        ('double', 'Double Play'),
        ('triple', 'Triple Play'),
    ], required=True, index=True, track_visibility='onchange')

    type_order = fields.Selection(string='Order Type', selection=[
        ('online', 'Online Order'),
        ('on_call', 'On-Call Order'),
    ], required=True, index=True, track_visibility='onchange')

    has_internet = fields.Boolean(string='Has Internet?', index=True, track_visibility='onchange')
    has_cable = fields.Boolean(string='Has Cable?', index=True, track_visibility='onchange')
    has_voiceline = fields.Boolean(string='Has Voice Line?', index=True, track_visibility='onchange')

    internet_package_id = fields.Many2one(string='Internet Package', comodel_name='product.product', index=True, domain=_filter_internet_products, track_visibility='onchange')
    internet_promo_price = fields.Monetary(string='Price of Promotion', track_visibility='onchange')

    cable_package_id = fields.Many2one(string='Cable Package', comodel_name='product.product', index=True, domain=_filter_cable_products, track_visibility='onchange')
    cable_promo_price = fields.Monetary(string='Price of Promotion', track_visibility='onchange')
    cable_boxline_ids = fields.One2many(string='Box Line', comodel_name='jna.sales.order.spectrum.boxline', inverse_name='order_id', track_visibility='onchange')

    voiceline_package_id = fields.Many2one(string='Voice Line Package', comodel_name='product.product', index=True, domain=_filter_voiceline_products, track_visibility='onchange')
    voiceline_promo_price = fields.Monetary(string='Price of Promotion', track_visibility='onchange')
    voiceline_voiceline_ids = fields.One2many(string='Voice Line', comodel_name='jna.sales.order.spectrum.voiceline', inverse_name='order_id', track_visibility='onchange')

    installation_price = fields.Monetary(string='Installation Price', required=True, track_visibility='onchange')
    installation_date = fields.Datetime(string='Installation Date', required=True, copy=False, track_visibility='onchange')
    installation_type = fields.Selection(string='Installation Type', selection=[
        ('professional', 'Professional'),
        ('self_installation', 'Self Installation'),
    ], required=True, index=True, track_visibility='onchange')

    amount = fields.Monetary(string='Total Amount', compute='_compute_total_amount', required=True, store=True, readonly=True, track_visibility='onchange', default=0.00)
    number_confirmation = fields.Char(string='Confirmation Number', required=True, track_visibility='onchange')
    number_account = fields.Char(string='Account Number', required=True, track_visibility='onchange')

    @api.depends('internet_promo_price', 'cable_promo_price', 'voiceline_promo_price', 'cable_boxline_ids.price_total')
    def _compute_total_amount(self):
        for order in self:
            amount = order.internet_promo_price + order.cable_promo_price + order.voiceline_promo_price
            for boxline in order.cable_boxline_ids:
                amount += boxline.price_total
            order.amount = amount

    @api.onchange('internet_package_id')
    def _autofill_internet_promo_price(self):
        for order in self:
            order.internet_promo_price = order.internet_package_id.list_price

    @api.onchange('cable_package_id')
    def _autofill_cable_promo_price(self):
        for order in self:
            order.cable_promo_price = order.cable_package_id.list_price

    @api.onchange('voiceline_package_id')
    def _autofill_voiceline_promo_price(self):
        for order in self:
            order.voiceline_promo_price = order.voiceline_package_id.list_price
