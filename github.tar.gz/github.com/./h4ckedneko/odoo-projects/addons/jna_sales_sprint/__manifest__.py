{
    'name': 'JNA Sprint Sales',
    'version': '1.0.0',
    'summary': 'Integrate Sprint Sales',
    'description': 'A custom sales app that integrates Sprint to the JNA Platform.',
    'author': 'Lyntor Paul Figueroa',
    'website': 'https://www.jnaenter.com',
    'license': 'OPL-1',
    'category': 'Sales',
    'depends': [
        'jna_sales',
    ],
    'data': [
        'security/res_groups_data.xml',
        'security/ir.model.access.csv',
        'data/product_category_data.xml',
        'views/sales_order_tree.xml',
        'views/sales_order_form.xml',
        'views/sales_order_action.xml',
        'views/menu.xml',
    ],
    'application': True,
    'installable': True,
}
