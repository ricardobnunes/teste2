from odoo import models, fields, api

class SalesOrderSprint(models.Model):
    _name = 'jna.sales.order.sprint'
    _description = 'JNA Sprint Sales Order'
    _inherit = ['jna.sales.ordermixin']

    is_customer_porting_numbers = fields.Selection(string='Is Customer Porting Numbers?', selection=[
        ('yes', 'Yes'),
        ('no', 'No'),
    ], required=True, index=True, track_visibility='onchange', default='no')

    has_newline = fields.Boolean(string='Has New Line?', index=True, track_visibility='onchange')
    has_existingline = fields.Boolean(string='Has Existing Line?', index=True, track_visibility='onchange')
    has_insurance = fields.Boolean(string='Has Insurance?', index=True, track_visibility='onchange')

    newline_ids = fields.One2many(string='New Line', comodel_name='jna.sales.order.sprint.newline', inverse_name='order_id', track_visibility='onchange')
    existingline_ids = fields.One2many(string='Existing Line', comodel_name='jna.sales.order.sprint.existingline', inverse_name='order_id', track_visibility='onchange')
    insuranceline_ids = fields.One2many(string='Insurance Line', comodel_name='jna.sales.order.sprint.insuranceline', inverse_name='order_id', track_visibility='onchange')

    quantity_port_number = fields.Integer(string='How Many Port Numbers?', required=True, track_visibility='onchange')

    which_phone = fields.Char(string='Which Phone?', required=True, track_visibility='onchange')
    sold_bargain_devices = fields.Integer(string='Bargain Devices Sold', required=True, track_visibility='onchange')

    amount = fields.Monetary(string='Total Amount', compute='_compute_total_amount', required=True, store=True, readonly=True, track_visibility='onchange', default=0.00)
    number_confirmation = fields.Char(string='Confirmation Number', required=True, track_visibility='onchange')
    number_account = fields.Char(string='Account Number', required=True, track_visibility='onchange')

    @api.depends('newline_ids.price_total', 'existingline_ids.price_total', 'insuranceline_ids.price_total')
    def _compute_total_amount(self):
        for order in self:
            amount = 0.00
            for newline in order.newline_ids:
                amount += newline.price_total
            for existingline in order.existingline_ids:
                amount += existingline.price_total
            for insuranceline in order.insuranceline_ids:
                amount += insuranceline.price_total
            order.amount = amount
