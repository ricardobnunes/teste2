from odoo import models, fields, api

class SalesOrderVivintLine(models.Model):
    _name = 'jna.sales.order.vivint.line'
    _description = 'JNA Vivint Sales Order Line'
    _order = 'order_id, id'

    @api.model
    def _filter_products(self):
        return [('categ_id', 'child_of', self.env.ref('jna_sales_vivint.product_category_all').id)]

    order_id = fields.Many2one(string='Order', comodel_name='jna.sales.order.vivint', required=True, index=True, readonly=True, ondelete='cascade')
    currency_id = fields.Many2one(string='Currency', comodel_name='res.currency', required=True, index=True, readonly=True, related='order_id.currency_id')
    product_id = fields.Many2one(string='Product', comodel_name='product.product', required=True, index=True, domain=_filter_products)
    quantity = fields.Integer(string='Quantity', required=True, default=1)
    price_unit = fields.Monetary(string='Unit Price', compute='_compute_unit_price', required=True, store=True, readonly=True, default=0.00)
    price_total = fields.Monetary(string='Total Price', compute='_compute_total_price', required=True, store=True, readonly=True, default=0.00)

    @api.depends('product_id.list_price')
    def _compute_unit_price(self):
        for line in self:
            # TODO: Make a product free when included in a bundle.
            # TODO: Customer may choose two free products.
            line.price_unit = line.product_id.list_price

    @api.depends('price_unit', 'quantity')
    def _compute_total_price(self):
        for line in self:
            line.price_total = line.price_unit * line.quantity
