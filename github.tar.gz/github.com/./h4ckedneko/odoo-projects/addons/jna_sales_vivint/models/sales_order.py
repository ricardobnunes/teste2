from odoo import models, fields, api

class SalesOrderVivint(models.Model):
    _name = 'jna.sales.order.vivint'
    _description = 'JNA Vivint Sales Order'
    _inherit = ['jna.sales.ordermixin']

    @api.model
    def _filter_package_products(self):
        return [('categ_id', 'child_of', self.env.ref('jna_sales_vivint.product_category_package').id)]

    package_id = fields.Many2one(string='Package', comodel_name='product.product', required=True, index=True, domain=_filter_package_products, track_visibility='onchange')

    contract = fields.Selection(string='Contract Duration', selection=[
        (60, '60 Months'),
        (42, '42 Months'),
    ], required=True, index=True, track_visibility='onchange')

    bundle = fields.Selection(string='Type of Bundling', selection=[
        ('starter', 'Vivint Starter Kit'),
        ('takeover', 'Vivint Takeover Starter Kit'),
        ('reactivate', 'Activating Existing Vivint System'),
    ], required=True, index=True, track_visibility='onchange')

    line_ids = fields.One2many(string='Order Line', comodel_name='jna.sales.order.vivint.line', inverse_name='order_id', track_visibility='onchange')
    pay_now = fields.Boolean(string='Pay everything now?', index=True, track_visibility='onchange')

    amount = fields.Monetary(string='Total Amount', compute='_compute_total_amount', required=True, store=True, readonly=True, track_visibility='onchange', default=0.00)
    number_confirmation = fields.Char(string='Confirmation Number', required=True, track_visibility='onchange')
    number_account = fields.Char(string='Account Number', required=True, track_visibility='onchange')

    @api.depends('package_id', 'line_ids.price_total')
    def _compute_total_amount(self):
        for order in self:
            amount = order.package_id.list_price
            for line in order.line_ids:
                amount += line.price_total
            order.amount = amount
