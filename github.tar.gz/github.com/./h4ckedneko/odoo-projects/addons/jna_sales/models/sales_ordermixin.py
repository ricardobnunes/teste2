from odoo import models, fields, api

class SalesOrderMixin(models.AbstractModel):
    _name = 'jna.sales.ordermixin'
    _description = 'JNA Sales Order Mixin'
    _inherit = ['mail.thread']
    _inherits = {'jna.sales.order': 'parent_order_id'}

    parent_order_id = fields.Many2one(string='Parent Order', comodel_name='jna.sales.order', required=True, ondelete='cascade')

    # We need to redefine these methods because they are not inherited in delegation.
    # See https://www.odoo.com/documentation/10.0/reference/orm.html#inheritance-and-extension
    @api.multi
    def mark_confirmed(self):
        for order in self:
            order.parent_order_id.mark_confirmed()
    @api.multi
    def mark_approved(self):
        for order in self:
            order.parent_order_id.mark_approved()
    @api.multi
    def mark_worklisted(self):
        for order in self:
            order.parent_order_id.mark_worklisted()
    @api.multi
    def mark_paid(self):
        for order in self:
            order.parent_order_id.mark_paid()
    @api.multi
    def mark_cancelled(self):
        for order in self:
            order.parent_order_id.mark_cancelled()
    @api.multi
    def mark_chargeback(self):
        for order in self:
            order.parent_order_id.mark_chargeback()

    @api.onchange('partner_id')
    def _autofill_customer_info(self):
        for order in self:
            # The address reference field is from the original addon.
            order.address_street = order.partner_id.address_reference
            order.address_city = order.partner_id.city
            order.address_state_id = order.partner_id.state_id
            order.address_zipcode = order.partner_id.zip
            order.phone = order.partner_id.phone
            order.email = order.partner_id.email
