from odoo import models, fields, api

class SalesOrder(models.Model):
    _name = 'jna.sales.order'
    _description = 'JNA Sales Order'
    _order = 'date_order desc, id desc'
    _inherit = ['mail.thread']

    name = fields.Char(string='Order Reference', required=True, index=True, readonly=True, copy=False)
    user_id = fields.Many2one(string='Salesperson', comodel_name='res.users', required=True, index=True, readonly=True, default=lambda self: self.env.user)
    company_id = fields.Many2one(string='Company', comodel_name='res.company', required=True, index=True, readonly=True, default=lambda self: self.env.user.company_id)
    currency_id = fields.Many2one(string='Currency', comodel_name='res.currency', required=True, index=True, readonly=True, default=lambda self: self.env.user.company_id.currency_id)
    partner_id = fields.Many2one(string='Customer', comodel_name='res.partner', required=True, index=True)

    sales_order_id = fields.Many2one(string='Sales Order', comodel_name='sale.order', readonly=True)
    sales_order_intercompany_id = fields.Many2one(string='Intercompany Sales Order', comodel_name='sale.order', readonly=True)

    commission_dealer = fields.Monetary(string='Dealer Commission', readonly=True, related='sales_order_id.amount_total', default=0.00)
    commission_jna = fields.Monetary(string='JNA Commission', readonly=True, related='sales_order_intercompany_id.amount_total', default=0.00)
    commission_employee = fields.Monetary(string='Employee Commission', default=0.00)
    earning = fields.Monetary(string='Total Earning', readonly=True, default=0.00)
    refund = fields.Monetary(string='JNA Refund', readonly=True, default=0.00)

    state = fields.Selection(string='Order Status', selection=[
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('worklisted', 'Worklisted'),
        ('approved', 'Approved'),
        ('paid', 'Paid'),
        ('cancelled', 'Cancelled'),
        ('chargeback', 'Chargeback'),
    ], required=True, index=True, readonly=True, copy=False, track_visibility='onchange', default='draft')

    date_order = fields.Datetime(string='Order Date', required=True, copy=False, track_visibility='onchange', default=fields.Datetime.now)
    date_confirm = fields.Datetime(string='Confirmation Date', readonly=True, copy=False, track_visibility='onchange')
    date_approve = fields.Datetime(string='Approve Date', readonly=True, copy=False, track_visibility='onchange')

    address_street = fields.Text(string='Street', required=True, track_visibility='onchange')
    address_unit = fields.Char(string='Unit or Apartment', track_visibility='onchange')
    address_city = fields.Char(string='City', required=True, track_visibility='onchange')
    address_state_id = fields.Many2one(string='State', comodel_name='res.country.state', required=True, track_visibility='onchange')
    address_zipcode = fields.Char(string='Zip Code', required=True, track_visibility='onchange')

    phone = fields.Char(string='Phone Number', required=True, track_visibility='onchange')
    phone2 = fields.Char(string='Phone Number #2', track_visibility='onchange')
    email = fields.Char(string='Email', required=True, track_visibility='onchange')
    notes = fields.Text(string='Notes', track_visibility='onchange')

    @api.multi
    def _create_sales_order(self):
        # ..
        return None

    @api.multi
    def _create_intercompany_sales_order(self):
        # ..
        return None

    @api.model
    def create(self, vals):
        # The sequence is from the original addon.
        vals['name'] = self.env['ir.sequence'].next_by_code('sale.order.release')
        return super(SalesOrder, self).create(vals)

    @api.multi
    def mark_confirmed(self):
        for order in self:
            order.state = 'confirmed'
            order.date_confirm = fields.Datetime.now()

    @api.multi
    def mark_approved(self):
        for order in self:
            order.state = 'approved'
            order.date_approve = fields.Datetime.now()
            order._create_sales_order()
            order._create_intercompany_sales_order()

    @api.multi
    def mark_worklisted(self):
        for order in self:
            order.state = 'worklisted'

    @api.multi
    def mark_paid(self):
        for order in self:
            order.state = 'paid'

    @api.multi
    def mark_cancelled(self):
        for order in self:
            order.state = 'cancelled'

    @api.multi
    def mark_chargeback(self):
        for order in self:
            order.state = 'chargeback'
