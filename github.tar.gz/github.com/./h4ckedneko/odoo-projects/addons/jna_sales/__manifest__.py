{
    'name': 'JNA Sales',
    'version': '1.0.0',
    'summary': 'Integrate Custom Sales',
    'description': 'The base module for custom sales app of the JNA Platform.',
    'author': 'Lyntor Paul Figueroa',
    'website': 'https://www.jnaenter.com',
    'license': 'OPL-1',
    'category': 'Sales',
    'depends': [
        'base',
        'web',
        'sale',
        'sales_team',
        'product',
        'mail',

        # This is the original addon of JNA Platform
        # and our code needs to be compatible with it.
        'jna_sale',
    ],
    'data': [
        'security/res_groups_data.xml',
        'security/ir.model.access.csv',
        'security/ir_rule_data.xml',
        'views/sales_order_form.xml',
        'views/sales_order_tree.xml',
        'views/assets.xml',
        'views/menu.xml',
    ],
}
